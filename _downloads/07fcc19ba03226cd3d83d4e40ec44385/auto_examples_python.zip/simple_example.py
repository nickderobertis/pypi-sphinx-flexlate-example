"""
Example Notebook
================

This is an example notebook to show how notebook examples in the docs
look.

"""

print("woo")

from IPython.display import display, HTML
display(HTML('<img src="https://http.cat/200"></img>'))


######################################################################
# Heading 2
# ---------
# 


######################################################################
# Heading 3
# ~~~~~~~~~
# 
# And a paragraph, then an equation.
# 


######################################################################
# .. math::
# 
# 
#    \sum_i^n {a_i b_i}
# 